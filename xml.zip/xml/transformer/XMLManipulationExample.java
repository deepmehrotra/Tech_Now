package xml.transformer;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import swift.saa.xsd.saa_2.DataPDU;

public class XMLManipulationExample {
    public static void main(String[] args) {
        try {
            // Step 1: Prepare JAXB-annotated Java Classes

            // Step 2: Read XML into Java Object
            JAXBContext jaxbContext = JAXBContext.newInstance(DataPDU.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            DataPDU rootElement = (DataPDU) unmarshaller.unmarshal(new File("src/main/java/xml/transformer/sample.xml"));

            // Step 3: Modify Java Object
            // Assuming you want to change a field named "fieldName" in one of the nested objects
            rootElement.getBody().getDocument().getFIToFIPmtCxlReq().getUndrlyg().getTxInf().setOrgnlUETR("new-value");

            // Step 4: Write Java Object back to XML
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(rootElement, new File("src/main/java/xml/transformer/updatedfile.xml"));

            System.out.println("XML file updated successfully.");
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}
